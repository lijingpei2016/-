//
//  LJP999_ViewController.h
//  LJP999
//
//  Created by LJP on 2023/12/13.
//

#import <UIKit/UIKit.h>
#import <LJP666/LJP66Header.h>

NS_ASSUME_NONNULL_BEGIN

//static int ceshitongztbl = 111; Redefinition of 'ceshitongztbl'
#define LJPPodCount 5


@interface LJP999_ViewController : UIViewController

@property (nonatomic, strong)UIView *ceshitongshuxing;

- (void)ceshitongming;

+ (void)text;

@end

NS_ASSUME_NONNULL_END

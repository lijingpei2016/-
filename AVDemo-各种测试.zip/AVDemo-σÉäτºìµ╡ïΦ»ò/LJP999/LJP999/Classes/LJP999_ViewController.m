//
//  LJP999_ViewController.m
//  LJP999
//
//  Created by LJP on 2023/12/13.
//

#import "LJP999_ViewController.h"

@interface LJP999_ViewController ()

@end

@implementation LJP999_ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

+ (void)text {
    NSLog(@"%s", __func__);
    NSLog(@"测试调用另外一个pod库的方法");
    [LJP66_ViewController textAdd];
}

- (void)ceshitongming {
}

@end

//
//  LJP999AppDelegate.h
//  LJP999
//
//  Created by git on 12/13/2023.
//  Copyright (c) 2023 git. All rights reserved.
//

@import UIKit;

@interface LJP999AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end

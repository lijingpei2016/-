//
//  main.m
//  LJP999
//
//  Created by git on 12/13/2023.
//  Copyright (c) 2023 git. All rights reserved.
//

@import UIKit;
#import "LJP999AppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([LJP999AppDelegate class]));
    }
}

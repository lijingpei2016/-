//
//  LJP999ViewController.m
//  LJP999
//
//  Created by git on 12/13/2023.
//  Copyright (c) 2023 git. All rights reserved.
//

#import "LJP999ViewController.h"

@interface LJP999ViewController ()

@end

@implementation LJP999ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end

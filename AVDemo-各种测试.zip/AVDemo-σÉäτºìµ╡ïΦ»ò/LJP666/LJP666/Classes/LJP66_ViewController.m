//
//  LJP66_ViewController.m
//  LJP666
//
//  Created by LJP on 2023/12/13.
//

#import "LJP66_ViewController.h"
#import "LJP_API.h"
#import "LJP_View.h"

@interface LJP66_ViewController ()

@end

@implementation LJP66_ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    int a = [LJP_API requestAPI];

    LJP_View *view = [[LJP_View alloc] init];
    view.frame = CGRectMake(0, 0, 60, 30);

    [self.view addSubview:view];
    view.center = self.view.center;

    [view setLabelText:@"4"];
    NSLog(@"a == %d", a);
}

- (void)ceshitongming {
}

+ (void)textAdd {
    NSLog(@"%s", __func__);
}

@end

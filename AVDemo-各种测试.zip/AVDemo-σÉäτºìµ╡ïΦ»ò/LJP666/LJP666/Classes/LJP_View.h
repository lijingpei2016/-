//
//  LJP_View.h
//  LJP666
//
//  Created by LJP on 2023/12/13.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface LJP_View : UIView

- (void)setLabelText:(NSString *)str;

@end

NS_ASSUME_NONNULL_END

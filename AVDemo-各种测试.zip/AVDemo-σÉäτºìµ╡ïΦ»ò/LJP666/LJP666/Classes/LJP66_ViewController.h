//
//  LJP66_ViewController.h
//  LJP666
//
//  Created by LJP on 2023/12/13.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

static int ceshitongztbl = 999;

#define LJPPodCount 5

@interface LJP66_ViewController : UIViewController

@property (nonatomic, strong) UIView *ceshitongshuxing;

- (void)ceshitongming;
+ (void)textAdd;

@end

NS_ASSUME_NONNULL_END

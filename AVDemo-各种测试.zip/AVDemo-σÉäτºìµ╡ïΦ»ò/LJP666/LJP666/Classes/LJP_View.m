//
//  LJP_View.m
//  LJP666
//
//  Created by LJP on 2023/12/13.
//

#import "LJP_View.h"

@interface LJP_View ()

@property (nonatomic, strong) UILabel *label;

@end

@implementation LJP_View

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.backgroundColor = UIColor.orangeColor;
        self.label = [[UILabel alloc] init];
        self.label.textColor = UIColor.whiteColor;
        self.label.frame = CGRectMake(0, 0, 100, 30);
        [self addSubview:self.label];
        self.label.center = self.center;
    }
    return self;
}

- (void)setLabelText:(NSString *)str {
    self.label.text = str;
}

@end

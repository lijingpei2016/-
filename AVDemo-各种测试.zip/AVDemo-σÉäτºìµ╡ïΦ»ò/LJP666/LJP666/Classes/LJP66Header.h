//
//  LJP66Header.h
//  Pods
//
//  Created by LJP on 2023/12/13.
//

#ifndef LJP66Header_h
#define LJP66Header_h

#import "LJP66_ViewController.h"

#endif /* LJP66Header_h */

//
//  LJP_API.m
//  LJP666
//
//  Created by LJP on 2023/12/13.
//

#import "LJP_API.h"

@implementation LJP_API

+ (int)requestAPI {
    return 4;
}

@end

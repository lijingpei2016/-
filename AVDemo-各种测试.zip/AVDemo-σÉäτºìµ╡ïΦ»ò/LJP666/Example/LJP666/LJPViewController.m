//
//  LJPViewController.m
//  LJP666
//
//  Created by git on 12/13/2023.
//  Copyright (c) 2023 git. All rights reserved.
//

#import "LJPViewController.h"
#import <LJP666/LJP66Header.h>

@interface LJPViewController ()

@end

@implementation LJPViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.

    NSLog(@"ceshitongztbl == %d", ceshitongztbl);
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    LJP66_ViewController *vc = [[LJP66_ViewController alloc] init];
    [self presentViewController:vc animated:YES completion:NULL];
}

@end

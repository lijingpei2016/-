//
//  main.m
//  LJP666
//
//  Created by git on 12/13/2023.
//  Copyright (c) 2023 git. All rights reserved.
//

@import UIKit;
#import "LJPAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([LJPAppDelegate class]));
    }
}

//
//  LJPAppDelegate.h
//  LJP666
//
//  Created by git on 12/13/2023.
//  Copyright (c) 2023 git. All rights reserved.
//

@import UIKit;

@interface LJPAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end

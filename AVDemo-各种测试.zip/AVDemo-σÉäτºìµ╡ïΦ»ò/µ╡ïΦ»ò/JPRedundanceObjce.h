//
//  JPRedundanceObjce.h
//  AVDemo
//
//  Created by LJP on 2023/10/21.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface JPRedundanceObjce : NSObject

//冗余方法
- (void)redundanceMethods;

@end

NS_ASSUME_NONNULL_END

//
//  JPRedundanceObjce.m
//  AVDemo
//
//  Created by LJP on 2023/10/21.
//

#import "JPRedundanceObjce.h"

@implementation JPRedundanceObjce

- (void)redundanceMethods {
    NSLog(@"%s", __func__);
    [self redundanceMethods1];
}

- (void)redundanceMethods1 {
    NSLog(@"%s", __func__);
    [self redundanceMethods2];
}

- (void)redundanceMethods2 {
    NSLog(@"%s", __func__);
    [self redundanceMethods3];
}

- (void)redundanceMethods3 {
    NSLog(@"%s", __func__);
    [self redundanceMethods4];
}

- (void)redundanceMethods4 {
    NSLog(@"%s", __func__);
    [self redundanceMethods5];
}

- (void)redundanceMethods5 {
    NSLog(@"%s", __func__);
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self aaabbb];
    });
}

- (void)aaabbb {
    NSLog(@"%s", __func__);
//    NSLog(@"%@", 1);
}

@end

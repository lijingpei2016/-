//
//  JPODRTTestViewController.m
//  AVDemo
//
//  Created by LJP on 2023/11/1.
//

#import "JPODRTTestViewController.h"
#import "JPChildViewController.h"

@interface JPODRTTestViewController ()

@end

@implementation JPODRTTestViewController

- (void)viewDidAppear:(BOOL)animated {
    NSLog(@"%s", __func__);
}

- (void)viewWillAppear:(BOOL)animated {
    NSLog(@"%s", __func__);
}

- (void)viewWillDisappear:(BOOL)animated {
    NSLog(@"%s", __func__);
}

- (void)viewDidDisappear:(BOOL)animated {
    NSLog(@"%s", __func__);
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = UIColor.whiteColor;
    return;

    NSMutableSet *set = [[NSMutableSet alloc] init];
    [set addObject:@"tag1"];
    NSBundleResourceRequest *request = [[NSBundleResourceRequest alloc] initWithTags:set];
    request.loadingPriority = NSBundleResourceRequestLoadingPriorityUrgent;

    // 判断资源是否存在
    [request conditionallyBeginAccessingResourcesWithCompletionHandler:^(BOOL resourcesAvailable) {
        if (resourcesAvailable) {
            return;
        }

        // 资源不存在请求资源 可以在之前调用
        [request beginAccessingResourcesWithCompletionHandler:^(NSError *_Nullable error) {
            NSLog(@"%@", request.progress);
            if (error) {
                NSLog(@"%@", error);
                return;
            }

            [request endAccessingResources];
            NSLog(@"%@", request.bundle);
        }];
    }];

    //和平常一样写
    UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 100, 100)];
    imageView.image = [UIImage imageNamed:@"a"];
    [self.view addSubview:imageView];
}

- (void)showChildViewControllerView {
    JPChildViewController *childVC = [[JPChildViewController alloc] init];
//    [self addChildViewController:childVC];
    
    [self.view.window addSubview:childVC.view]; //测试在win上
//    [self.view addSubview:childVC.view];
//    [childVC didMoveToParentViewController:self];
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [childVC.view removeFromSuperview]; //模拟点击了关闭按钮
    });
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    NSLog(@"添加子vc");
    [self showChildViewControllerView];
}

@end

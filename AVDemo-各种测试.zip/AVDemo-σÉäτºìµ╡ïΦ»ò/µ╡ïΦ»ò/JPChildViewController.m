//
//  JPChildViewController.m
//  AVDemo
//
//  Created by LJP on 2023/11/1.
//

#import "JPChildViewController.h"
#import "JPObject.h"

@interface JPChildViewController ()

@property(nonatomic, strong)JPObject *obj;

@end

@implementation JPChildViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = UIColor.orangeColor;
    self.obj = [JPObject new];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    NSLog(@"%s", __func__);
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    NSLog(@"%s", __func__);
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    NSLog(@"%s", __func__);
    if (self.obj) {
        NSLog(@"viewWillDisappear obj == %@",self.obj);
    }
}

- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
    NSLog(@"%s", __func__);
    if (self.obj) {
        NSLog(@"viewDidDisappear obj == %@",self.obj);
    }
}

- (void)dealloc {
    NSLog(@"%s", __func__);
    if (self.obj) {
        NSLog(@"dealloc obj == %@",self.obj);
    }
}

@end

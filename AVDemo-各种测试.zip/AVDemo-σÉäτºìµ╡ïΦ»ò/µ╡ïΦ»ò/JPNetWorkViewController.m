//
//  JPNetWorkViewController.m
//  AVDemo
//
//  Created by LJP on 2023/11/7.
//

#import "JPNetWorkViewController.h"

@interface JPNetWorkViewController ()

@property(nonatomic, strong)NSDate *startTime1;

@end

@implementation JPNetWorkViewController


- (instancetype)init
{
    self = [super init];
    if (self) {
        self.startTime1 = [NSDate date];
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.view.backgroundColor = UIColor.whiteColor;
    
    NSDate *endTime1 = [NSDate date];
    NSTimeInterval elapsedTime1 = [endTime1 timeIntervalSinceDate:self.startTime1];

    NSLog(@" init viewDidLoad 方法运行的时间  Method took %f seconds to run.", elapsedTime1);

    [self post];
    
    
}

- (void)post
{
    
    NSDate *startTime1 = [NSDate date];

//1.创建会话对象
    NSURLSession *session = [NSURLSession sharedSession];
//2.根据会话对象创建task
    NSURL *url = [NSURL URLWithString:@"https://image.baidu.com/search/detail"];

//3.创建可变的请求对象
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];

//4.修改请求方法为POST
    request.HTTPMethod = @"POST";

//5.设置请求体
    request.HTTPBody = [@"ct=503316480&z=0&ipn=false&word=刘亦菲&hs=0&pn=-1&spn=0&di=baikeimg&pi=&rn=1&tn=baiduimagedetail&is=&istype=&ie=utf-8&oe=utf-8&in=&cl=2&lm=-1&st=&ln=undefined&fr=ala&fmq=undefined&fm=undefined&ic=&s=&se=&sme=&tab=&width=&height=&face=&cg=star&bdtype=0&oriquery=&objurl=http%3A%2F%2Fimgsrc.baidu.com%2Fbaike%2Fpic%2Fitem%2Fe4dde71190ef76c604622df99816fdfaae5167b4.jpg&fromurl=http%3A%2F%2Fbaike.baidu.com%2Fsubview%2F3064%2F13233367.htm&gsm=" dataUsingEncoding:NSUTF8StringEncoding];

//6.根据会话对象创建一个Task(发送请求）
/*
 第一个参数：请求对象
 第二个参数：completionHandler回调（请求完成【成功|失败】的回调）
            data：响应体信息（期望的数据）
            response：响应头信息，主要是对服务器端的描述
            error：错误信息，如果请求失败，则error有值
 */
    NSURLSessionDataTask *dataTask = [session dataTaskWithRequest:request completionHandler:^(NSData *_Nullable data, NSURLResponse *_Nullable response, NSError *_Nullable error) {
        //8.解析数据
        NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:nil];
        NSLog(@"%@", dict);
        
        
        NSDate *endTime1 = [NSDate date];
        NSTimeInterval elapsedTime1 = [endTime1 timeIntervalSinceDate:startTime1];

        NSLog(@" POST 方法运行的时间  Method took %f seconds to run.", elapsedTime1);
        
    }];

    //7.执行任务
    [dataTask resume];
}

- (void)network {
    NSDate *startTime1 = [NSDate date];
    //    1. 创建一个url
    NSURL *url = [NSURL URLWithString:@"https://www.baidu.com/img/PCtm_d9c8750bed0b3c7d089fa7d55720d6cf.png"];
    //    2. 创建一个网络请求，网络请求不指定方法默认是GET
    NSURLRequest *request = [[NSURLRequest alloc] initWithURL:url];
    //    request.HTTPMethod = @"GET";

    //    自定义请求配置
    //    NSURLSessionConfiguration *config = [[NSURLSessionConfiguration alloc] init];
    //    config.timeoutIntervalForRequest= 20;// 请求超超时时间
    //    //...还有很多参数
    //    NSURLSession *session = [NSURLSession sessionWithConfiguration: config];
    //    3. 创建网络管理
    NSURLSession *session = [NSURLSession sharedSession];

    //    4. 创建一个网络任务
    /*
        第一个参数 : 请求对象
        第二个参数 :
            completionHandler回调 ( 请求完成 ["成功"or"失败"] 的回调 )
            data : 响应体信息(期望的数据)
            response : 响应头信息,主要是对服务器端的描述
            error : 错误信息 , 如果请求失败 , 则error有值
    */
    NSURLSessionDataTask *task = [session dataTaskWithRequest:request completionHandler:^(NSData *_Nullable data, NSURLResponse *_Nullable response, NSError *_Nullable error) {
        // data就是服务器返回的数据,response为服务器的响应
        if (!error) {
            // 强转为NSHTTPURLResponse

            NSHTTPURLResponse *res = (NSHTTPURLResponse *)response;
            if (res.statusCode == 200) {
//            // 更新UI必须回到主线程
//                dispatch_async(dispatch_get_main_queue(), ^{
//                                   self.imgView.image = [UIImage imageWithData:data];
//                });
                NSDate *endTime1 = [NSDate date];
                NSTimeInterval elapsedTime1 = [endTime1 timeIntervalSinceDate:startTime1];

                NSLog(@" 方法运行的时间 1 Method took %f seconds to run.", elapsedTime1);
            }
        } else {
            NSLog(@"报错啦,%@", error);
        }
    }];
    //    5. 开启任务
    [task resume];
}

@end

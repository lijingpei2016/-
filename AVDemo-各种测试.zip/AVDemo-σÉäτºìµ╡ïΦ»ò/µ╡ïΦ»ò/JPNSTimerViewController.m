//
//  JPNSTimerViewController.m
//  AVDemo
//
//  Created by LJP on 2023/10/23.
//

#import "JPNSTimerViewController.h"

@interface JPNSTimerViewController ()

@property (nonatomic, strong) NSMutableArray *arr;

@end

@implementation JPNSTimerViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];

    self.arr = [NSMutableArray array];

    for (int i = 0; i < 5; i++) {
        NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:(i + 10) target:self selector:@selector(timerFired:) userInfo:nil repeats:YES];
        [self.arr addObject:timer];
    }
}

- (void)timerFired:(id)obj {
    NSLog(@"%s", __func__);
}

@end

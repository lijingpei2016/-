//
//  JPNetWorkViewController.h
//  AVDemo
//
//  Created by LJP on 2023/11/7.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface JPNetWorkViewController : UIViewController

@end

NS_ASSUME_NONNULL_END

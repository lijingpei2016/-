//
//  JPObject.m
//  AVDemo
//
//  Created by LJP on 2023/11/5.
//

#import "JPObject.h"

@implementation JPObject

- (void)dealloc {
    NSLog(@"%s", __func__);
}

@end

//
//  JPPodViewController.m
//  AVDemo
//
//  Created by LJP on 2023/12/13.
//

#import "JPPodViewController.h"
#import <LJP666/LJP66Header.h>
#import <LJP999/LJP999_ViewController.h>


@interface JPPodViewController ()

@end

@implementation JPPodViewController

- (void)viewDidLoad
{
    [super viewDidLoad];

    self.view.backgroundColor = UIColor.whiteColor;

    NSLog(@"ceshitongztbl == %d", ceshitongztbl);
    
    [LJP999_ViewController text];
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    LJP66_ViewController *vc = [[LJP66_ViewController alloc] init];
    [self presentViewController:vc animated:YES completion:NULL];

    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self dismissViewControllerAnimated:YES completion:NULL];
    });
}

@end

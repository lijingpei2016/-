//
//  JPCollectionViewViewController.m
//  AVDemo
//
//  Created by LJP on 2023/11/1.
//

#import <UIKit/UIKit.h>

@interface MyCollectionViewCell : UICollectionViewCell

@property (strong, nonatomic) UIImageView *topImage;

@property (strong, nonatomic) UILabel *botlabel;

@end

@implementation MyCollectionViewCell

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        _topImage = [[UIImageView alloc] initWithFrame:CGRectMake(10, 0, 70, 70)];
        _topImage.backgroundColor = [UIColor redColor];
        [self.contentView addSubview:_topImage];

        _botlabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 80, 70, 30)];
        _botlabel.textAlignment = NSTextAlignmentCenter;
        _botlabel.textColor = [UIColor blueColor];
        _botlabel.font = [UIFont systemFontOfSize:15];
        _botlabel.backgroundColor = [UIColor purpleColor];
        [self.contentView addSubview:_botlabel];
    }

    return self;
}

@end

#import "JPCollectionViewViewController.h"
#import "JPCollectionView.h"

@interface JPCollectionViewViewController ()<UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout>

@property (nonatomic, strong) JPCollectionView *mainCollectionView;
@property (nonatomic, strong) NSMutableArray *datas0;
@property (nonatomic, strong) NSMutableArray *datas1;
@property (nonatomic, strong) NSMutableArray *datas2;

@end

@implementation JPCollectionViewViewController

//测试数据的增长速度
- (void)addObject {
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self addObject];

        for (int i = 0; i < 1000; i++) {
            [self.datas2 addObject:@"1"];
        }
        NSLog(@"数据增加了1000个 self.datas2.count == %ld", self.datas2.count);
    });
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor whiteColor];
    [self addObject];

    NSDate *startTime1 = [NSDate date];

    //1.初始化layout
    UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
    //设置collectionView滚动方向
//    [layout setScrollDirection:UICollectionViewScrollDirectionHorizontal];
    //设置headerView的尺寸大小
    layout.headerReferenceSize = CGSizeMake(self.view.frame.size.width, 100);
    //该方法也可以设置itemSize
    layout.itemSize = CGSizeMake(110, 150);

    //2.初始化collectionView
    self.mainCollectionView = [[JPCollectionView alloc] initWithFrame:self.view.bounds collectionViewLayout:layout];
    self.mainCollectionView.backgroundColor = [UIColor clearColor];
    [self.view addSubview:self.mainCollectionView];

    //3.注册collectionViewCell
    //注意，此处的ReuseIdentifier 必须和 cellForItemAtIndexPath 方法中 一致 均为 cellId
    [self.mainCollectionView registerClass:[MyCollectionViewCell class] forCellWithReuseIdentifier:@"cellId"];

    //注册headerView  此处的ReuseIdentifier 必须和 cellForItemAtIndexPath 方法中 一致  均为reusableView
    [self.mainCollectionView registerClass:[UICollectionReusableView class] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"reusableView"];

    //4.设置代理
    self.mainCollectionView.delegate = self;
    self.mainCollectionView.dataSource = self;

//
//    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
//        [self->mainCollectionView reloadData];
//        [self->mainCollectionView reloadData];
//        [self->mainCollectionView reloadData];
//    });

    self.datas0 = [NSMutableArray arrayWithArray:@[@"1", @"1", @"1", @"1", @"1"]];
    self.datas1 = [NSMutableArray arrayWithArray:@[@"1", @"1", @"1", @"1", @"1"]];
    self.datas2 = [NSMutableArray arrayWithArray:@[@"1", @"1", @"1", @"1", @"1"]];

    [self.mainCollectionView reloadData];

//    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
////        [self.mainCollectionView reloadData];
//        NSLog(@"count1:%ld", (long)[self.mainCollectionView numberOfItemsInSection:0]); // 会回调dataSource询问
//        NSLog(@"count2:%ld", (long)[self.mainCollectionView numberOfItemsInSection:0]); // 直接返回
//    });

//    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
//        [self.datas removeObjectAtIndex:0];
//        [self.mainCollectionView performBatchUpdates:^{
//            [self.mainCollectionView deleteItemsAtIndexPaths:@[[NSIndexPath indexPathForRow:0 inSection:0]]];
//        } completion:^(BOOL finished) {
//        }];
//    });

    NSDate *endTime1 = [NSDate date];
    NSTimeInterval elapsedTime1 = [endTime1 timeIntervalSinceDate:startTime1];

    NSLog(@" mainCollectionView 方法运行的时间  Method took %f seconds to run.", elapsedTime1);
}

//- (void)viewWillLayoutSubviews {
//    NSLog(@"%s", __func__);
//    [super viewWillLayoutSubviews];
//}

#pragma mark collectionView代理方法
//返回section个数
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    NSLog(@" 返回section个数 %s", __func__);
    return 2;
}

//每个section的item个数
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    NSLog(@"%s 每个section的item个数", __func__);

//    return self.datas.count;

    if (section == 0) {
        return self.datas0.count;
    } else {
        return self.datas1.count;
    }
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    NSLog(@"%s", __func__);

    MyCollectionViewCell *cell = (MyCollectionViewCell *)[collectionView dequeueReusableCellWithReuseIdentifier:@"cellId" forIndexPath:indexPath];

    cell.botlabel.text = [NSString stringWithFormat:@"{%ld,%ld}", (long)indexPath.section, (long)indexPath.row];

    cell.backgroundColor = [UIColor yellowColor];

    return cell;
}

//设置每个item的尺寸
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    return CGSizeMake(90, 130);
}

//footer的size
//- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout referenceSizeForFooterInSection:(NSInteger)section
//{
//    return CGSizeMake(10, 10);
//}

//header的size
//- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout referenceSizeForHeaderInSection:(NSInteger)section
//{
//    return CGSizeMake(10, 10);
//}

//设置每个item的UIEdgeInsets
- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    return UIEdgeInsetsMake(10, 10, 10, 10);
}

//设置每个item水平间距
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section
{
    return 10;
}

//设置每个item垂直间距
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section
{
    return 15;
}

//通过设置SupplementaryViewOfKind 来设置头部或者底部的view，其中 ReuseIdentifier 的值必须和 注册是填写的一致，本例都为 “reusableView”
- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath
{
    UICollectionReusableView *headerView = [collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"reusableView" forIndexPath:indexPath];
    headerView.backgroundColor = [UIColor grayColor];
    UILabel *label = [[UILabel alloc] initWithFrame:headerView.bounds];
    label.text = @"这是collectionView的头部";
    label.font = [UIFont systemFontOfSize:20];
    [headerView addSubview:label];
    return headerView;
}

//点击item方法
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    MyCollectionViewCell *cell = (MyCollectionViewCell *)[collectionView cellForItemAtIndexPath:indexPath];
    NSString *msg = cell.botlabel.text;
    NSLog(@"%@", msg);

    //    [self.datas removeObjectAtIndex:0];
    //    [self.mainCollectionView reloadData];

//    UIViewController *vc = [(UIViewController *)[NSClassFromString(@"JPChildViewController") alloc] init];
//    [self.navigationController pushViewController:vc animated:YES];

//    [self.datas removeObjectAtIndex:0];
//    [self.mainCollectionView deleteItemsAtIndexPaths:@[[NSIndexPath indexPathForRow:0 inSection:0]]];

//    [self.datas addObject:@"1"];
//    [self.mainCollectionView insertItemsAtIndexPaths:@[[NSIndexPath indexPathForRow:self.datas.count-1 inSection:0]]];

//    [self.datas removeObjectAtIndex:indexPath.row];
//    [self.mainCollectionView performBatchUpdates:^{
//        [self.mainCollectionView deleteItemsAtIndexPaths:@[indexPath]];
//    } completion:^(BOOL finished) {
//    }];
//

//    [self.datas addObject:@"1"];
//    [self.mainCollectionView insertItemsAtIndexPaths:@[[NSIndexPath indexPathForRow:self.datas.count-1 inSection:0]]];

//    [self.datas addObject:@"1"];
////    [self.mainCollectionView insertItemsAtIndexPaths:@[[NSIndexPath indexPathForRow:0 inSection:0],[NSIndexPath indexPathForRow:self.datas.count-1 inSection:1]]];
//
//    [self.mainCollectionView performBatchUpdates:^{
//        [self.mainCollectionView insertItemsAtIndexPaths:@[[NSIndexPath indexPathForRow:0 inSection:0],[NSIndexPath indexPathForRow:self.datas.count-1 inSection:1]]];
//    } completion:^(BOOL finished) {
//    }];

//    dispatch_async(dispatch_get_global_queue(0, 0), ^{
//        [self.datas0 addObject:@"1"];
//        [self.datas1 addObject:@"1"];
//
//        NSLog(@"0count == %ld, 1count == %ld", self.datas0.count, self.datas1.count);
//    });

    dispatch_sync(dispatch_get_global_queue(0, 0), ^{
        [self.datas0 addObject:@"1"];
        [self.datas1 addObject:@"1"];
        NSLog(@"0count == %ld, 1count == %ld", self.datas0.count, self.datas1.count);
    });

    [self.mainCollectionView performBatchUpdates:^{
//        [self.mainCollectionView insertItemsAtIndexPaths:@[[NSIndexPath indexPathForRow:self.datas0.count - 1 inSection:0]]]; //如果注释了这一行就会出问题
        [self.mainCollectionView reloadSections:[NSIndexSet indexSetWithIndex:1]]; //如果注释了这一行就会出问题
    } completion:^(BOOL finished) {
    }];

    //总结：当section里面的返回row个数变换了，但没有刷新，就会出问题，iOS12系统奔溃，13有日志
    //解决方案 可以知道的那一组的IndexPaths 不知道的就刷一组
}

@end

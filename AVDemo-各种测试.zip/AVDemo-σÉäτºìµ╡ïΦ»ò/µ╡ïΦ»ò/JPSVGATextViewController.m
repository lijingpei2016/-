//
//  JPSVGATextViewController.m
//  AVDemo
//
//  Created by LJP on 2023/10/23.
//

#import "JPSVGATextViewController.h"
#import <SVGAPlayer/SVGA.h>

@interface JPSVGATextViewController ()

@property (nonatomic, strong) SVGAPlayer *player;
@property (nonatomic, assign) BOOL isPlaying;

@end

@implementation JPSVGATextViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    self.view.backgroundColor = [UIColor whiteColor];

    for (int i = 0; i < 2; i++) {
        SVGAPlayer *player = [[SVGAPlayer alloc] initWithFrame:CGRectMake(100, i * 21 + 50, 20, 20)];

        [self.view addSubview:player];

        player.loops = 0;

        SVGAParser *parser = [[SVGAParser alloc]init];

        [parser parseWithNamed:@"520" inBundle:[NSBundle mainBundle] completionBlock:^(SVGAVideoEntity *_Nonnull videoItem) {
            if (videoItem != nil) {
                player.videoItem = videoItem;
                [player startAnimation];
                self.isPlaying = YES;
            }
        } failureBlock:^(NSError *_Nonnullerror) {
            NSLog(@"error == %@", _Nonnullerror);
        }];
    }
}

- (void)viewDidAppear:(BOOL)animated {
    NSLog(@"%s", __func__);
}

- (void)viewWillAppear:(BOOL)animated {
    NSLog(@"%s", __func__);
}

- (void)viewWillDisappear:(BOOL)animated {
    NSLog(@"%s", __func__);
}

- (void)viewDidDisappear:(BOOL)animated {
    NSLog(@"%s", __func__);
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
//    if (self.isPlaying) {
//        [self.player stopAnimation];
//        self.isPlaying = NO;
//    } else {
//        [self.player startAnimation];
//        self.isPlaying = YES;
//    }
//

    UIViewController *vc = [(UIViewController *)[NSClassFromString(@"JPNULLViewController") alloc] init];
    [self.navigationController pushViewController:vc animated:YES];

//    vc.modalPresentationStyle = UIModalPresentationOverFullScreen;
//    [self presentViewController:vc animated:YES completion:nil];

//    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
//        [self.player stopAnimation];
//    });
}

@end

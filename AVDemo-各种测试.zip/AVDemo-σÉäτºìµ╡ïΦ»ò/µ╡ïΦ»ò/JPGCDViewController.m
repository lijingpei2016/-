//
//  JPGCDViewController.m
//  AVDemo
//
//  Created by LJP on 2023/12/15.
//

#import "JPGCDViewController.h"

@interface JPGCDViewController ()

@property (atomic, assign) int num;

@property (nonatomic, weak) UIView *view1;

@property (nonatomic, strong) UIView *superView;
@property (nonatomic, strong) UIView *subView;

@end

@implementation JPGCDViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = UIColor.whiteColor;
    NSLog(@"点击屏幕");

    [self testSubView];
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    //测试用weak修饰的对象
    self.view1 = [[UIView alloc] initWithFrame:CGRectMake(100, 100, 100, 100)];
    self.view1.backgroundColor = UIColor.orangeColor;

    int a = 3 / 2;
    NSLog(@"a == %d", a);

    [self.view addSubview:self.view1];

    [self test5];
}

//测试超过父视图是否可以响应手势 结论：超出的范围不能响应 没超出的可以
- (void)testSubView {
    self.superView = [[UIView alloc] initWithFrame:CGRectMake(20, 100, 100, 100)];
    self.superView.backgroundColor = UIColor.orangeColor;
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(clickSuperView)];
    [self.superView addGestureRecognizer:tap];
    [self.view addSubview:self.superView];

//    self.subView = [[UIView alloc] initWithFrame:CGRectMake(20, 20, 50, 50)];
    self.subView = [[UIView alloc] initWithFrame:CGRectMake(80, 20, 50, 50)];
    self.subView.backgroundColor = UIColor.blueColor;
    UITapGestureRecognizer *tap1 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(clickSubView)];
    [self.subView addGestureRecognizer:tap1];
    [self.superView addSubview:self.subView];
}

- (void)clickSubView {
    NSLog(@"%s", __func__);
}

- (void)clickSuperView {
    NSLog(@"%s", __func__);
}

- (void)test1 {
//    dispatch_queue_t queue = dispatch_queue_create("com.HotpotCat.zai", DISPATCH_QUEUE_SERIAL);

    dispatch_queue_t queue = dispatch_queue_create("com.HotpotCat.zai", DISPATCH_QUEUE_CONCURRENT);
    NSLog(@"1");
    dispatch_async(queue, ^{
        NSLog(@"2");
        dispatch_async(queue, ^{
            NSLog(@"3");
        });
        NSLog(@"4");
    });
    NSLog(@"5");
}

- (void)test2 {
    CFAbsoluteTime time = CFAbsoluteTimeGetCurrent();
    dispatch_queue_t queue = dispatch_queue_create("com.12321312", DISPATCH_QUEUE_SERIAL);

    dispatch_async(queue, ^{
        NSLog(@"1: %f", CFAbsoluteTimeGetCurrent() - time);
        method();
    });

    //dispatch_async
    dispatch_sync(queue, ^{
        NSLog(@"2: %f", CFAbsoluteTimeGetCurrent() - time);
        method();
    });

    method();
    NSLog(@"3: %f", CFAbsoluteTimeGetCurrent() - time);
}

void method()
{
    sleep(3);
}

- (void)test3 {
    dispatch_queue_t queue = dispatch_queue_create("com.HotpotCat.zai", DISPATCH_QUEUE_SERIAL);
    self.num = 0;
    while (self.num < 5) {
        dispatch_async(queue, ^{
            self.num++;
        });
    }
    NSLog(@"result: %d", self.num);
}

- (void)test4 {
    self.num = 0;
    for (int i = 0; i < 10000; i++) {
        dispatch_queue_t queue1 = dispatch_queue_create("com.HotpotCat.zai", DISPATCH_QUEUE_SERIAL);
//        dispatch_queue_t queue2 = dispatch_queue_create("com.HotpotCat.zai", DISPATCH_QUEUE_CONCURRENT);
//        dispatch_queue_t queue3 = dispatch_get_main_queue();

        //dispatch_sync
        dispatch_async(queue1, ^{
//            NSLog(@"currentThread == :%@", [NSThread currentThread]);
            self.num++;
        });
    }
    NSLog(@"result: %d", self.num);
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        NSLog(@"after result: %d", self.num);
    });
}

- (void)test5 {
//        dispatch_queue_t concurrentQueue = dispatch_queue_create("HotpotCat", DISPATCH_QUEUE_CONCURRENT);
//        dispatch_queue_t concurrentQueue = dispatch_get_global_queue(0, 0);
    dispatch_queue_t concurrentQueue = dispatch_get_main_queue();

    dispatch_async(concurrentQueue, ^{
        NSLog(@"1");
    });
    dispatch_async(concurrentQueue, ^{
        NSLog(@"2");
    });
    dispatch_barrier_async(concurrentQueue, ^{
        NSLog(@"3:%@", [NSThread currentThread]);
    });
    dispatch_async(concurrentQueue, ^{
        NSLog(@"4");
    });
    NSLog(@"5");
}

- (void)test6 {
    NSMutableArray *array = [NSMutableArray array];
    dispatch_queue_t concurrentQueue = dispatch_queue_create("Hotpot", DISPATCH_QUEUE_CONCURRENT);
    for (int i = 0; i < 1000; i++) {
        //        dispatch_barrier_async(concurrentQueue, ^{
        [array addObject:@(i)];
        //        });
    }

    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        NSLog(@"count == %lu", (unsigned long)array.count);
    });
}

- (void)test7 {
    dispatch_queue_t global_queue = dispatch_get_global_queue(0, 0);
    dispatch_semaphore_t sem = dispatch_semaphore_create(0);
    dispatch_queue_t queue1 = dispatch_queue_create("HotpotCat", DISPATCH_QUEUE_CONCURRENT);

    dispatch_async(queue1, ^{
        NSLog(@"1 start  %@", [NSThread currentThread]);

        dispatch_semaphore_wait(sem, DISPATCH_TIME_FOREVER);

        NSLog(@"1 end");
    });

    //    dispatch_async(global_queue, ^{
    //        NSLog(@"2 start  %@", [NSThread currentThread]);
    //
    //        sleep(1);
    //        dispatch_semaphore_signal(sem);
    //
    //        NSLog(@"2 end");
    //    });
    //
    //
    //    dispatch_async(global_queue, ^{
    //        NSLog(@"3 start  %@", [NSThread currentThread]);
    //        NSLog(@"3 end");
    //    });

    for (int i = 100; i < 200; i++) {
        dispatch_async(queue1, ^{
            NSLog(@"%d start  %@", i, [NSThread currentThread]);
            dispatch_semaphore_wait(sem, DISPATCH_TIME_FOREVER);
            NSLog(@"%d end", i);
        });
    }

    dispatch_async(global_queue, ^{
        NSLog(@"global start  %@", [NSThread currentThread]);
    });
}

- (void)test8 {
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        NSLog(@"1");
        dispatch_sync(dispatch_get_main_queue(), ^{
            NSLog(@"2");
        });
        NSLog(@"3");
    });

    NSLog(@"4");

    while (1) {
    }

    NSLog(@"5");
}

- (void)test9 {
    dispatch_sync(dispatch_get_main_queue(), ^{
        NSLog(@"1");
    });
    NSLog(@"2");

    //    dispatch_async(dispatch_get_main_queue(), ^{
    //        NSLog(@"dispatch_get_main_queue :%@", [NSThread currentThread]);
    //    });
    //
    //    dispatch_async(dispatch_get_global_queue(0, 0), ^{
    //        NSLog(@"dispatch_get_global_queue :%@", [NSThread currentThread]);
    //    });
    //    NSLog(@"2");
}

- (void)test10 {
    dispatch_queue_t queue1 = dispatch_queue_create("com.HotpotCat.zai1", DISPATCH_QUEUE_CONCURRENT);
    dispatch_queue_t queue2 = dispatch_queue_create("com.HotpotCat.zai1", DISPATCH_QUEUE_CONCURRENT);

    NSMutableArray *array = [[NSMutableArray alloc] init];

    dispatch_async(queue1, ^{
        while (1) {
            if (array.count < 10) {
                [array addObject:@(array.count)];
            } else {
                [array removeAllObjects];
            }
        }
    });

    dispatch_async(queue2, ^{
        while (1) {
            for (NSNumber *ber in array) {
                NSLog(@"1ber == %@", ber);
            }

            NSArray *arr = array.copy;
            for (NSNumber *ber in arr) {
                NSLog(@"2ber == %@", ber);
            }

            NSMutableArray *mArr = array.mutableCopy;
            for (NSNumber *ber in mArr) {
                NSLog(@"2ber == %@", ber);
            }
        }
    });
}

@end

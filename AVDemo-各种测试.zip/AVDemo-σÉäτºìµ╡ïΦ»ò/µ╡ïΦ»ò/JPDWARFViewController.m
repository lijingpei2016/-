//
//  JPDWARFViewController.m
//  AVDemo
//
//  Created by LJP on 2023/10/29.
//

#import "JPDWARFViewController.h"

@interface JPDWARFViewController ()

@property (nonatomic, assign) int age;
@property (nonatomic, copy) NSString *name;

@end

@implementation JPDWARFViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    [self aaa];
}

- (void)aaa { //54字节
    NSLog(@"%s", __func__); //14
    [self bbb];
    [self ccc];
    [self ddd];
}

- (void)bbb { //48字节
    NSLog(@"%s", __func__);
    NSLog(@"哈哈哈bbb");
}

- (void)ccc { //48字节
    NSLog(@"%s", __func__);
    NSLog(@"哈哈哈ccc");
}

- (void)ddd { //108 6c
    NSLog(@"%s", __func__);
    NSLog(@"哈哈哈ddd");

    dispatch_async(dispatch_get_main_queue(), ^{
        NSLog(@"哈哈哈ddd");
    });
}

@end

//
//  JPCollectionView.m
//  AVDemo
//
//  Created by LJP on 2023/11/2.
//

#import "JPCollectionView.h"

@implementation JPCollectionView

- (void)layoutSubviews {
    NSLog(@"%s", __func__);
    [super layoutSubviews];
}

@end

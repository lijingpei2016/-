//
//  AshMallocObjectsOC.h
//  FlexTest
//
//  Created by crimsonho on 2021/3/25.
//

#import <Foundation/Foundation.h>

@interface AshMallocObjectsOC : NSObject

+ (NSArray*)appAliveObjectsOC;

@end

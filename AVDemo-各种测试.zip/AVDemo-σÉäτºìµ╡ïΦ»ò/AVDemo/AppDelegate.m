//
//  AppDelegate.m
//  AVDemo
//
//  Created by LJP on 2022/4/21.
//

#import "AppDelegate.h"
#import "ViewController.h"

#import <KSCrash/KSCrash.h>
#import <KSCrash/KSCrashInstallation.h>
#import <KSCrash/KSCrashInstallationEmail.h>
#import <KSCrash/KSHTTPMultipartPostBody.h>
#import "KSJSONCodecObjC.h"

//#include <libkern/OSAtomicDeprecated.h>
//#include <libkern/OSSpinLockDeprecated.h>
#import <libkern/OSAtomicQueue.h>
#import <dlfcn.h>

#include <malloc/malloc.h>
#include <mach/mach.h>

#import <mach-o/dyld.h>
#import <stdio.h>

#import "AshMallocObjectsOC.h"
#import "AshRetainChecker.h"

@interface AppDelegate ()

@end

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    CGRect re = [UIScreen mainScreen].bounds;
    self.window = [[UIWindow alloc] initWithFrame:CGRectMake(0, 0, re.size.width, re.size.height)];
    ViewController *vc = [[ViewController alloc] init];
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:vc];
    self.window.rootViewController = nav;
    [self.window makeKeyAndVisible];

    [self setupKSCrash];

    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(10 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
//        [self writerOrder];
    });

    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(4 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        NSLog(@"获取使用内存大小");
        int64_t memory = getMemoryUsage();
        NSLog(@" memory == %lld MB", memory / 1024 / 1024);
    });

//    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
//        [self showVMRegion];
//        [self showZoneName];
//    });

//    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
//        NSLog(@"枚举二进制图像");
//        enumerateBinaryImages();
//    });
    
//    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
//        [self showAppAliveObjects];
//    });

    return YES;
}

void enumerateBinaryImages()
{
    
//    _dyld_image-count可获取所有模块数目，dyld_get_image_name 可获取模块名称，dyld_get _image header可获取每个模块的起始地址， _dyld_get_image_vmaddr_slide获取单个模块的随机基址。
    
    
    uint32_t imageCount = _dyld_image_count();

    for (uint32_t i = 0; i < imageCount; i++) {
        const char *imageName = _dyld_get_image_name(i);
        uintptr_t imageBaseAddress = _dyld_get_image_header(i);

        printf("Image %d:\n", i);
        printf("Name: %s\n", imageName);
        printf("Base Address: 0x%lx\n", imageBaseAddress);
        printf("\n");
    }
}

- (void)setupKSCrash {
    KSCrashInstallation *installation = [self makeEmailInstallation];

    // 安装异常处理者，越早安装越好
    // 如下将自动记录崩溃信息，但是它不会自动发送报告
    [installation install];
    // 此方法是确认崩溃报告发送后，如何处理旧的崩溃。
    [KSCrash sharedInstance].deleteBehaviorAfterSendAll = KSCDeleteNever;
    // 发送崩溃日志
    [installation sendAllReportsWithCompletion:^(NSArray *reports, BOOL completed, NSError *error)
    {
        NSLog(@"发送崩溃日志");
    }];
}

// 获取内存使用情况
int64_t getMemoryUsage(void)
{
    int64_t memoryUsageInByte = 0;

    task_vm_info_data_t vmInfo;

    mach_msg_type_number_t count = TASK_VM_INFO_COUNT;

    kern_return_t kernelReturn = task_info(mach_task_self(), TASK_VM_INFO, (task_info_t)&vmInfo, &count);

    if (kernelReturn == KERN_SUCCESS) {
        memoryUsageInByte = (int64_t)vmInfo.phys_footprint;

//        int64_t virtual_size = (int64_t)vmInfo.virtual_size;
//        NSLog(@" virtual_size == %lld MB", virtual_size / 1024 / 1024);
    }

    return memoryUsageInByte;
}

extern int proc_regionfilename(int pid, uint64_t address, void *buffer, uint32_t buffersize) __OSX_AVAILABLE_STARTING(__MAC_10_5, __IPHONE_2_0);

- (void)showVMRegion {
    NSLog(@"显示VM区域");
    kern_return_t krc = KERN_SUCCESS;
    vm_address_t address = 0;
    vm_size_t size = 0;
    uint32_t depth = 1;
    pid_t pid = getpid();
    char buf[PATH_MAX];
    while (1) {
        struct vm_region_submap_info_64 info;
        mach_msg_type_number_t count = VM_REGION_SUBMAP_INFO_COUNT_64;
        krc = vm_region_recurse_64(mach_task_self(), &address, &size, &depth, (vm_region_info_64_t)&info, &count);
        if (krc == KERN_INVALID_ADDRESS) {
            break;
        }
        if (info.is_submap) {
            depth++;
        } else {
            //do stuff
            proc_regionfilename(pid, address, buf, sizeof(buf));

            printf("Found VM Region: %08x to %08x (depth=%d) 用户标签:%08x  用户有线计数：%u  引用计数：%u name:%s\n", (uint32_t)address, (uint32_t)(address + size), depth, info.user_tag, (uint32_t)info.user_wired_count, (uint32_t)info.ref_count, buf);
            address += size;
        }
    }
}

- (void)showZoneName {
    vm_address_t *zones = NULL;
    unsigned int zoneCount = 0;
    kern_return_t result = malloc_get_all_zones(TASK_NULL, NULL, &zones, &zoneCount);
    if (result == KERN_SUCCESS) {
        for (unsigned int i = 0; i < zoneCount; i++) {
            malloc_zone_t *zone = (malloc_zone_t *)zones[i];
            printf("Found zone name:%s\n", zone->zone_name);
        }
    }
}

- (void)showAppAliveObjects {
    NSLog(@"显示应用程序活动对象");
    NSArray *appAliveObjects = [AshMallocObjectsOC appAliveObjectsOC];
    NSLog(@"appAliveObjects == %@", appAliveObjects);
//        NSMutableArray *modelArray = [[NSMutableArray alloc] init];
//        for (id obj in appAliveObjects) {
//            AshRetainCheckerObjectModel *model = [[AshRetainCheckerObjectModel alloc] initWithObject:obj];
//            [modelArray addObject:model];
//        }
//        AshRetainChecker *retainChecker = [[AshRetainChecker alloc] init];
//        for (AshRetainCheckerObjectModel *model in modelArray) {
//            NSArray *logArray = [retainChecker findRetainWithObjectModel:model className:@"ViewController"];
//            NSLog(@"%@", logArray);
//        }
}

- (KSCrashInstallation *)makeEmailInstallation
{
//开发者邮件地址
    NSString *emailAddress = @"451082454@qq.com";
    KSCrashInstallationEmail *email = [KSCrashInstallationEmail sharedInstance];
    email.recipients = @[emailAddress];
    email.subject = @"Crash Report";
    email.message = @"This is a crash report";
    email.filenameFmt = @"crash-report-%d.txt.gz";

    [email setReportStyle:KSCrashEmailReportStyleApple useDefaultFilenameFormat:YES];
    return email;
}

// ============== hook ===========
//原子队列
static OSQueueHead symboList = OS_ATOMIC_QUEUE_INIT;
//定义符号结构体
typedef struct {
    void *pc;
    void *next;
}SymbolNode;

void __sanitizer_cov_trace_pc_guard(uint32_t *guard)
{
//    if (!*guard) return; //如果判空 会记录不到load方法 因为load方法传过来的guard是0

    void *PC = __builtin_return_address(0);

    SymbolNode *node = malloc(sizeof(SymbolNode));
    *node = (SymbolNode) { PC, NULL };

    //入队
    // offsetof 用在这里是为了入队添加下一个节点找到 前一个节点next指针的位置
    OSAtomicEnqueue(&symboList, node, offsetof(SymbolNode, next));
}

void __sanitizer_cov_trace_pc_guard_init(uint32_t *start,
                                         uint32_t *stop)
{
    static uint64_t N;  // Counter for the guards.
    if (start == stop || *start) return;  // Initialize only once.
    printf("INIT: %p %p\n", start, stop);
    for (uint32_t *x = start; x < stop; x++) {
        *x = ++N;  // Guards should start from 1.
    }
}

- (void)writerOrder {
    NSMutableArray<NSString *> *symbolNames = [NSMutableArray array];
    while (true) {
        //offsetof 就是针对某个结构体找到某个属性相对这个结构体的偏移量
        SymbolNode *node = OSAtomicDequeue(&symboList, offsetof(SymbolNode, next));
        if (node == NULL) break;
        Dl_info info;
        dladdr(node->pc, &info);

        NSString *name = @(info.dli_sname);

        // 添加 _
        BOOL isObjc = [name hasPrefix:@"+["] || [name hasPrefix:@"-["];
        NSString *symbolName = isObjc ? name : [@"_" stringByAppendingString:name];

        //去重
        if (![symbolNames containsObject:symbolName]) {
            [symbolNames addObject:symbolName];
        }
    }

    //取反
    NSArray *symbolAry = [[symbolNames reverseObjectEnumerator] allObjects];
    NSLog(@"%@", symbolAry);

    //时间戳
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];

    [formatter setDateFormat:@"YYYY-MM-dd HH:mm:ss"];

    NSDate *dateNow = [NSDate date];

    NSString *currentTime = [formatter stringFromDate:dateNow];

    //将结果写入到文件
    NSString *funcString = [symbolAry componentsJoinedByString:@"\n"];
    NSString *filePath = [NSTemporaryDirectory() stringByAppendingPathComponent:[NSString stringWithFormat:@"%@orlb.order", currentTime]];
    NSData *fileContents = [funcString dataUsingEncoding:NSUTF8StringEncoding];
    BOOL result = [[NSFileManager defaultManager] createFileAtPath:filePath contents:fileContents attributes:nil];
    if (result) {
        NSLog(@"%@", filePath);
    } else {
        NSLog(@"文件写入出错");
    }
}



@end

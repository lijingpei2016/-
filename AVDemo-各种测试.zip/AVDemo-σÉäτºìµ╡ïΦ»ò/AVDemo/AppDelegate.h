//
//  AppDelegate.h
//  AVDemo
//
//  Created by LJP on 2022/4/21.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow * window;


@end

